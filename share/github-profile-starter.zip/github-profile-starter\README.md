<!-- Generated from profile.config.json. Edit the config and rebuild. -->
<picture>
  <source media="(max-width: 600px)" srcset="./assets/01-hero-mobile.svg" />
  <img src="./assets/01-hero.svg" width="100%" alt="Your Name — Software Developer" />
</picture>

<p align="center"><strong>I build practical software and share what I learn.</strong></p>

<p align="center">
  <a href="https://example.com"><img src="./assets/badge-portfolio.svg" height="36" alt="Visit my portfolio" /></a>
  <a href="https://github.com/YOUR_USERNAME?tab=repositories"><img src="./assets/badge-repositories.svg" height="36" alt="Explore my repositories" /></a>
  <a href="https://github.com/YOUR_USERNAME"><img src="./assets/badge-github.svg" height="36" alt="Connect on GitHub" /></a>
</p>

<picture>
  <source media="(max-width: 600px)" srcset="./assets/02-vision-mobile.svg" />
  <img src="./assets/02-vision.svg" width="100%" alt="What I build: Useful applications and thoughtful interfaces.. What I explore: New tools, ideas and ways to solve problems.. What I share: My projects, experiments and learning notes." />
</picture>

<picture>
  <source media="(max-width: 600px)" srcset="./assets/03-stack-mobile.svg" />
  <img src="./assets/03-stack.svg" width="100%" alt="Java: Spring Boot · REST APIs. JavaScript: React · HTML · CSS. Python: SQL. Git &amp; GitHub: Version control. Your platform: Replace with your tools. Your interest: Replace with your focus" />
</picture>

<picture>
  <source media="(max-width: 600px)" srcset="./assets/04-projects-mobile.svg" />
  <img src="./assets/04-projects.svg" width="100%" alt="Project One: Explain a project you actually built. Mention who it helps or what it solves.. Project Two: Describe your second project here. Mark unfinished projects as in development." />
</picture>

<picture>
  <source media="(max-width: 600px)" srcset="./assets/06-activity-mobile.svg" />
  <img src="./assets/06-activity.svg" width="100%" alt="The commit journal: GitHub activity" />
</picture>

<p align="center"><a href="https://github.com/YOUR_USERNAME">View my repositories and contributions on GitHub ↗</a></p>

<a href="https://example.com">
<picture>
  <source media="(max-width: 600px)" srcset="./assets/05-connect-mobile.svg" />
  <img src="./assets/05-connect.svg" width="100%" alt="Visit Your Name’s portfolio" />
</picture>
</a>

<p align="center"><sub>A little code. A lot of curiosity.</sub></p>
